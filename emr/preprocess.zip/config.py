class Production:
    HOST = 'yji2.c1hiiq8ixpyr.ap-northeast-2.rds.amazonaws.com'
    PORT = 3306
    DATABASE = 'yji2'
    USERNAME = 'kadencho'
    PASSWORD = 'kadencho13'
    URL =  (f"jdbc:mysql:"
            f"//{HOST}:{PORT}"
            f"/{DATABASE}")